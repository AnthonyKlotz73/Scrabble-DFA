# Scrable_FInite_Project
A project that i worked on demonstrating the posible implementation of a DFA.

This project was initaly completed in spring of 2023 for a class project in Formal Languages and Finite Atomita
but was revised recently due to inate bugs and isues that were created.

This project now can be used as a fun Scrabble tool. AS of now only in the command line

# Issues solved:
1.0 release
*partner missunderstood the project and doubbled the inital work load, makeing it take 20 muinits to load the projects input file. 
    -FIXED  now loading only take 12 seconds (on my machine)

# Bugs
    -please note any issues with this program in the issues tab. I will look into solving them when they occur